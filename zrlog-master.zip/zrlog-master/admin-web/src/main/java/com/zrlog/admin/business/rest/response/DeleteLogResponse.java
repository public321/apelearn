package com.zrlog.admin.business.rest.response;

public class DeleteLogResponse {
    private boolean delete;

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }
}
