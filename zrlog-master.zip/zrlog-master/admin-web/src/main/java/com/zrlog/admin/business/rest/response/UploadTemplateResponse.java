package com.zrlog.admin.business.rest.response;

import com.zrlog.common.rest.response.StandardResponse;

public class UploadTemplateResponse extends StandardResponse {

}
