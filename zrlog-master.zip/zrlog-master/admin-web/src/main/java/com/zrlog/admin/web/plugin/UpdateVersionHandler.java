package com.zrlog.admin.web.plugin;

public interface UpdateVersionHandler {

    String getMessage();

    boolean isFinish();

    void start();
}
