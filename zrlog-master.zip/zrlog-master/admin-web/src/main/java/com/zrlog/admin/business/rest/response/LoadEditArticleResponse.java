package com.zrlog.admin.business.rest.response;

import com.zrlog.admin.business.rest.request.UpdateArticleRequest;

public class LoadEditArticleResponse extends UpdateArticleRequest {
}
